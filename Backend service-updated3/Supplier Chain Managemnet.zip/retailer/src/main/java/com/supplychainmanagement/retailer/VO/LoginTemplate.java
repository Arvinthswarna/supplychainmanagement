package com.supplychainmanagement.retailer.VO;

import lombok.Data;

@Data
public class LoginTemplate {
    private String retailerEmail;
    private String retailerPassword;
}

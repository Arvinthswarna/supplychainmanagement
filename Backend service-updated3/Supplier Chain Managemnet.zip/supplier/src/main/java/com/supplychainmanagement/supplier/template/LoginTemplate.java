package com.supplychainmanagement.supplier.template;

import lombok.Data;

@Data
public class LoginTemplate {
        private String supplierEmail;
        private String supplierPassword;
    }

